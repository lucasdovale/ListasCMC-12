function [a, b] = questao1()
% Encontre o intervalo [a, b] tal que qualquer K em [a, b] atende aos
% requisitos:
% Erro em regime para entrada rampa com inclinacao unitaria e <= 1.
% Margem de ganho GM >= 6 dB.

a = 2;
b = 3.0071;

end