function [K, z, p] = questao3()
% Projetar controlador com funcao de transferencia
% C(s) = K * (s - z) / (s * (s - p)).

K = 0;
z = 0;
p = 0;

end