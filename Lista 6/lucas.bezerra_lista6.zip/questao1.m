function limites = questao1()
% Determinar a faixa de valores de K tal que o sistema apresentado na
% na figura seja estavel.

% limites = [a, b];

a = -24/5;
b = 42;

end
