function [wcp, ganhoPM] = questao4()
% Determinar analiticamente a frequencia de cruzamento wcp e o ganho (aumento) de
% margem de fase (em graus) ganhoPM devido a troca do sensor.

wcp = 7.2996;
ganhoPM = (0.07 * wcp) * 180/pi;

end
