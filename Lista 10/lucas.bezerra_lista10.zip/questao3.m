function [GM, PM] = questao3()
% Determinar graficamente a margem de ganho GM e a margem de fase PM.

GM = 15;
PM = 80;

end