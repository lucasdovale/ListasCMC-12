function K = questao1()
% Determine K que deixa o sistema no limiar de estabilidade.

K = 0.6;

end