function [Kp, Kpsi] = questao5()
% Calcule os valores de Kp e Kpsi para que o sistema atenda aos requisitos
% no dominio da frequencia.

Kp = 4.3542;
Kpsi = 6.27;

end
