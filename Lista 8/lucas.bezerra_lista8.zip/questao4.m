function [Kmin, Kmax] = questao4()
% Calcule os valores minimo e maximo de K para que o sistema atenda aos
% requisitos.

Kmin = 450;
Kmax = 9050/9;

end
